#!/bin/sh

# BD Agent is installed two directories below this script's location
THIS_SCRIPT_DIR="$(cd "$(dirname "$0")"; pwd -P)"
BDROOT="$(dirname "$(dirname "$THIS_SCRIPT_DIR")")"

ROOTDIR=/tmp/bitdefender_logs
mkdir -p ${ROOTDIR}
BDUPD_INFO=${ROOTDIR}/BDUPD_INFO
mkdir -p ${BDUPD_INFO}

ETC_LOGGING=${BDROOT}/etc/logging
DAEMONSLOGS_PERSISTENT=${BDROOT}/var/log
DAEMONSLOGS_TMP=/tmp/bdlogs/${BDROOT}/var/log

# Other miscellaneous info.
cp ${BDROOT}/bitdefender-release                ${ROOTDIR}
ps -w                                           > ${ROOTDIR}/ps
dmesg                                           > ${ROOTDIR}/dmesg
top -b -n 1                                     > ${ROOTDIR}/top
uptime                                          > ${ROOTDIR}/uptime
date -R                                         > ${ROOTDIR}/date

cp ${BDROOT}/etc/bdupd.server ${BDUPD_INFO}
cp ${BDROOT}/var/upd/* ${BDUPD_INFO}

# Create the archive.
ARNAME=bitdefender_logs.tar.gz

tar -czf /tmp/${ARNAME} -C ${ROOTDIR} . ${ETC_LOGGING} ${DAEMONSLOGS_PERSISTENT} ${DAEMONSLOGS_TMP}
rm -rf ${ROOTDIR}

# Encrypt the archive.
PUBKEY=${BDROOT}/etc/logs-pub.pem
ENCSYMKEY=bitdefender_key.enc
TEMPKEY=/tmp/bitdefender-sym-key-temp

LD_LIBRARY_PATH=${BDROOT}/lib ${BDROOT}/bin/bdcrypto gen-sym-key -k ${TEMPKEY}
LD_LIBRARY_PATH=${BDROOT}/lib ${BDROOT}/bin/bdcrypto aes-encrypt -k ${TEMPKEY} -i /tmp/${ARNAME} -o /tmp/${ARNAME}.enc
LD_LIBRARY_PATH=${BDROOT}/lib ${BDROOT}/bin/bdcrypto rsa-encrypt -k ${PUBKEY} -i ${TEMPKEY} -o /tmp/${ENCSYMKEY}

tar -czf /tmp/${ARNAME} -C /tmp ${ENCSYMKEY} ${ARNAME}.enc
rm -f /tmp/${ENCSYMKEY} /tmp/${ARNAME}.enc ${TEMPKEY}

